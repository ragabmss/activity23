package com.msactivity.CurrencyConversionFactor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyConversionFactorApplicationTests {

	@Test
	void contextLoads() {
	}

}
